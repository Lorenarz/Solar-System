#!/bin/bash
#Please use the current script to download the whole content of request 786572566
wget "https://almascience.eso.org/dataPortal/requests/anonymous/786572566/ALMA/uid___A002_X3b3400_X90f/uid___A002_X3b3400_X90f.asdm.sdm.tar"
wget "https://almascience.eso.org/dataPortal/requests/anonymous/786572566/ALMA/uid___A002_X3b3400_Xaf3/uid___A002_X3b3400_Xaf3.asdm.sdm.tar"
