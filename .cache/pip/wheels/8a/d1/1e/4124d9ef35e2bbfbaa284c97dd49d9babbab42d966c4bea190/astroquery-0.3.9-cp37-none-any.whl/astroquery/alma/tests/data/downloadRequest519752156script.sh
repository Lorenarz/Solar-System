#!/bin/bash
#Please use the current script to download the whole content of request 519752156
wget "https://almascience.eso.org/dataPortal/requests/anonymous/519752156/ALMA/2011.0.00121.S_2012-07-30_001_of_002.tar/2011.0.00121.S_2012-07-30_001_of_002.tar"
wget "https://almascience.eso.org/dataPortal/requests/anonymous/519752156/ALMA/2011.0.00121.S_2012-07-30_002_of_002.tar/2011.0.00121.S_2012-07-30_002_of_002.tar"
